import { Component, OnInit } from '@angular/core';
import { ToastController, LoadingController, Events } from '@ionic/angular';
import { UserService } from '../services/user/user.service';
import { config } from '../config';
import { Router } from '@angular/router';
@Component({
  selector: 'app-upsell-products',
  templateUrl: './upsell-products.page.html',
  styleUrls: ['./upsell-products.page.scss'],
})
export class UpsellProductsPage implements OnInit {
IMAGES_URL:any;
userId:any;
loading:any;
upsell_products:any;
my_cart_products:any;
my_wish_products:any;
errors : any = ['',null,undefined];
  constructor(public userService: UserService,public toastController:ToastController,public loadingController:LoadingController, public events: Events, public router: Router) {
  	this.IMAGES_URL = config.IMAGES_URL;
    var token = localStorage.getItem('sin_auth_token');
    this.userId = this.userService.decryptData(token,config.ENC_SALT);
    this.getCartProductsIds();
  }

  ngOnInit() {
  }

  getCartProductsIds(){
    this.userService.postData({user_id: this.userId == 0 ? localStorage.getItem('guestUserId') : this.userId},'getCartProductsIds').subscribe((result) => {
      this.my_cart_products = result.products;
      this.my_wish_products = result.wishlist;
      this.getUpsellProducts();
    },
    err => {
      this.getUpsellProducts();
      this.my_cart_products = [];
      this.my_wish_products = [];
    });
  }

  getUpsellProducts(){
    this.userService.postData({limit:'15',user_id: this.userId },'bestSellerProducts').subscribe((result) => {
      this.upsell_products = result.products;
    },
    err => {
      this.upsell_products = [];
    });
  }

  addToCart(product_id,product_sale_price,product_purchase_price){
  	// if(this.userId == 0){
  	// 	this.router.navigate(['/login']);
  	// }
  	// else{
	    this.presentLoading();
	    this.userService.postData({product_id:product_id,user_id: this.userId == 0 ? localStorage.getItem('guestUserId') : this.userId,product_qty:1,is_variation: false, product_price:0, product_variations:[]},'addTocart').subscribe((result) => {
	      this.stopLoading();
	      if(result.status == 1){
	        this.my_cart_products.push(product_id);
	        var p_price;
	        if(this.errors.indexOf(product_sale_price) == -1 && product_sale_price != product_purchase_price){
	          p_price = product_sale_price;
	        }
	        else{
	          p_price = product_purchase_price;
	        }
          // this.getUpsellProducts();
	        this.events.publish('cart_updated:true', {items_in_cart:this.my_cart_products.length,cart_price:p_price,isAdd:true});
	        this.presentToast('Product added to cart.','success');
	      }
	      else{
	        this.presentToast('Error,Please try after some time.','danger');
	      }
	    },
	    err => {
	      this.stopLoading();
	      this.presentToast('Error,Please try after some time.','danger');
	    });
	// }
  }

  addToWish(product_id){
    // if(this.userId == 0){
    //   this.router.navigate(['/login']);
    // }
    // else{
      this.presentLoading();
      this.userService.postData({product_id:product_id,user_id: this.userId == 0 ? localStorage.getItem('guestUserId') : this.userId, wish_title: null, is_new: this.userId == 0 ? 3 : 0 , wishlist_id: null }, 'addWishlistNew').subscribe((result) => {
        this.stopLoading();
        if(result.status == 1){
          this.my_wish_products.push(product_id);
          this.presentToast('Product added to wishlist.','success');
        }
        else{
          this.presentToast('Error,Please try after some time.','danger');
        }
      },
      err => {
        this.stopLoading();
        this.presentToast('Error,Please try after some time.','danger');
      });
    // }
  }

  productDetails(productId){
  	this.router.navigate(['/product-details/'+productId]);
  }

  async presentToast(message,color) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
      position: 'bottom',
      color: color,
      showCloseButton: true
    });
    toast.present();
  }

  async presentLoading() {
    this.loading = await this.loadingController.create();
    await this.loading.present();
  }

  async stopLoading() {
    if(this.loading != undefined){
      await this.loading.dismiss();
    }
    else{
      var self = this;
      setTimeout(function(){
        self.stopLoading();
      },1000);
    }
  }

}
