export const config = {
  	API_URL : 'http://dev.indiit.solutions/TJ/dev/dev/api',
  	IMAGES_URL : 'http://dev.indiit.solutions/TJ/dev/dev/public/uploads',
  	ENC_SALT: 'gd58_N9!ysS',
  	BASE_URL: 'https://siniyetu.tk/',
  	PAYPAL_ENVIRONMENT: 'PayPalEnvironmentSandbox', // Environments: PayPalEnvironmentNoNetwork, PayPalEnvironmentSandbox, PayPalEnvironmentProduction
  	PAYPAL_SANDBOX_CLIENT_ID: 'AUf1yanX3_FsOIiJnRyw46AHhULmUgH0bgLP0iLq0zlzSwqJDtEb3XMxy4DIXPHbG9esnoBomF39NiM6',
  	PAYPAL_PRODUCTION_CLIENT_ID: ''
}; 
