export class Shared {
    static doSomething() { console.log('abc') }
}